<?php
/*
	foreach ($arrResponseXML as $key => $value) {
		# code...
		//var_dump($value['SOAP:BODY']);
	    $arrBody = $value['SOAP:BODY'];
		foreach ($arrBody as $key1 => $value1) {
			# code...
			
			$arrReturn = $value1['RETURN'];
		//	var_dump($arrReturn);
			foreach ($arrReturn as $key2 => $value2) {
				# code...
				$arrDocumentoNotarial = $value2['DOCUMENTONOTARIAL'];
				
				foreach ($arrDocumentoNotarial as $key3 => $value3) {
					# code...
					$status = $arrDocumentoNotarial['STATUS'];
					$arrDocumento = $arrDocumentoNotarial['DOCUMENTO'];




				}

			}

		}
	}*/